#!/usr/bin/env python3
from hashlib import sha256
from config import p, q, g, y, x, flag
from random import randrange

H = lambda m : int.from_bytes(sha256(m).digest(), 'big')
SIZE = (1 << x.bit_length()) - 1
NUM_KILLCODE = 24
killcode = b'rm -rf --no-preserve-root /'


class Chall:

    def __init__(self):
        self.state = randrange(SIZE)
        self.a = randrange(SIZE)
        self.b = randrange(SIZE)

    def rand(self):
        self.state = ((self.a * self.state) + self.b) % SIZE
        return self.state >> 32

    def sign(self, m):
        while True:
            k = self.rand()
            try:
                r = pow(g, k, p) % q
                assert r
                s = (pow(k, q - 2, q) * (H(m) + x * r)) % q
                assert s
                break
            except:
                continue
        return r, s


if __name__ == '__main__':
    chall = Chall()
    print(chall.a)
    print(chall.b)

    for i in range(NUM_KILLCODE):
        sig = chall.sign(killcode)
        print(sig)

    # Tell me the next killcode with proper signature
    r, s = chall.sign(killcode)
    assert flag == 'flag{' + f'{r}_{s}_{killcode.decode()}' + '}'