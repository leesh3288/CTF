#!/usr/bin/env python3
import platform
import random
from typing import List
from secret import flag

SIZE = (1 << 96) - 1


def chunkify(data: int, length: int) -> List:
    MASK = (1 << length) - 1
    result = []
    while data > 0:
        result.append(data & MASK)
        data >>= length
    return result


def unchunkify(data: List, length: int) -> int:
    result = 0
    for i, d in enumerate(data):
        result += d << (i * length)
    return result


def gen_seqnum() -> List:
    init = random.randrange(SIZE)
    c = chunkify(init, 24)
    for i in range(4):
        c = [c[0] ^ c[1], c[1] ^ c[2], c[2] ^ c[3], c[0] ^ c[i] ^ c[2]]
    fini = unchunkify(c, 24)
    return fini


def encrypt(flag: int) -> int:
    flag_chunks = chunkify(flag, 96)
    flag_chunks = list(map(lambda c : c ^ gen_seqnum(), flag_chunks))
    enc_flag = unchunkify(flag_chunks, 96)
    return enc_flag


if __name__ == '__main__':
    print(f'version : {platform.python_version()}')
    for _ in range(250):
        print(f'Initial Seqnum : {gen_seqnum()}')
    flag = int.from_bytes(flag, byteorder='big')
    print(encrypt(flag))