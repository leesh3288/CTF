#!/bin/bash
LD_PRELOAD=./libjemalloc.so ./firmware