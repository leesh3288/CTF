#include <linux/device.h>
#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/random.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/mm.h>

#define DEVICE_NAME "chall"
#define CLASS_NAME "chall"
#define NOTE_SIZE (0x1000 * 16)

MODULE_AUTHOR("r4j");
MODULE_LICENSE("GPL");

static int chall_open(struct inode *inode, struct file *file);
static int chall_release(struct inode *inode, struct file *file);
static int chall_mmap(struct file *file, struct vm_area_struct *vma);
static ssize_t chall_write(struct file *filp, const char __user *buf, size_t count, loff_t *f_pos);

static int major;
static struct class *chall_class = NULL;
static struct device *chall_device = NULL;
static struct file_operations chall_fops = {
    .open = chall_open,
    .release = chall_release,
    .mmap = chall_mmap,
    .write = chall_write,
    .owner = THIS_MODULE
};

typedef struct chall_ctx {
    struct page * note;
    unsigned long size;
} chall_ctx;

int chall_opens = 0;

static vm_fault_t chall_vm_fault(struct vm_fault *vmf) {
    struct vm_area_struct *vma = vmf->vma;
    chall_ctx * ctx = vma->vm_file->private_data;
    
    unsigned long offset = vmf->address - vma->vm_start;
    int pgoff = offset >> PAGE_SHIFT;
    int pfn = page_to_pfn(ctx->note) + pgoff;

    return vmf_insert_pfn(vma, vmf->address, pfn);
}

static const struct vm_operations_struct chall_vm_ops = {
    .fault = chall_vm_fault,
};

static int chall_open(struct inode *inode, struct file *file) {
    chall_ctx * ctx;
    if(chall_opens++)
        return -ENOMEM;

    ctx = kzalloc(sizeof(chall_ctx), GFP_KERNEL);
    if(ctx == NULL)
        return -ENOMEM;
    
    ctx->note = alloc_pages(GFP_KERNEL, get_order(NOTE_SIZE));
    if(ctx->note == NULL) {
        kfree(ctx);
        return -ENOMEM;
    }

    ctx->size = NOTE_SIZE;
    file->private_data = ctx;
    return 0;
}

static int chall_release(struct inode *inode, struct file *file) {
    chall_ctx * ctx = file->private_data;
    if(ctx) {
        __free_pages(ctx->note, get_order(NOTE_SIZE));
        kfree(ctx);
        file->private_data = NULL;
    }
    return 0;
}

static ssize_t chall_write(struct file *file, const char __user *buf, size_t count, loff_t *f_pos) {
    chall_ctx * ctx;
    unsigned char * note_ptr;

    if (file->f_pos < 0 || file->f_pos >= NOTE_SIZE) return 0;
    if (count < 0) return 0;
    if (count > NOTE_SIZE) count = NOTE_SIZE - *f_pos;

    ctx = file->private_data;
    note_ptr = page_to_virt(ctx->note) + *f_pos;
    if (copy_from_user(note_ptr, buf, count)) return -EFAULT;

    *f_pos += count;
    return count;
}

static int chall_mmap(struct file *file, struct vm_area_struct *vma) {
    chall_ctx * ctx = file->private_data;
    unsigned int vma_size = vma->vm_end - vma->vm_start;
    if(vma_size != ctx->size)
        return -EINVAL;

    if (vma->vm_flags & VM_WRITE)
        return -EPERM;

    vma->vm_flags &= ~VM_MAYWRITE;
    vma->vm_file = file;
    vma->vm_ops = &chall_vm_ops;
    vma->vm_flags |= VM_DONTDUMP | VM_PFNMAP | VM_DONTEXPAND | VM_DONTCOPY;

    remap_pfn_range(vma, vma->vm_start, page_to_pfn(ctx->note), vma_size, vma->vm_page_prot);
    return 0;
}

static int __init init_chall(void) {
    major = register_chrdev(0, DEVICE_NAME, &chall_fops);
    if (major < 0)
        return -1;

    chall_class = class_create(THIS_MODULE, CLASS_NAME);
    if (IS_ERR(chall_class)) {
        unregister_chrdev(major, DEVICE_NAME);
        return -1;
    }

    chall_device =
        device_create(chall_class, 0, MKDEV(major, 0), 0, DEVICE_NAME);
    if (IS_ERR(chall_device)) {
        class_destroy(chall_class);
        unregister_chrdev(major, DEVICE_NAME);
        return -1;
    }

    return 0;
}

static void __exit exit_chall(void) {
    device_destroy(chall_class, MKDEV(major, 0));
    class_unregister(chall_class);
    class_destroy(chall_class);
    unregister_chrdev(major, DEVICE_NAME);
}

module_init(init_chall);
module_exit(exit_chall);
