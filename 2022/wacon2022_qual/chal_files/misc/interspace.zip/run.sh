#/bin/sh

docker kill interspace 2>/dev/null
docker build . -t interspace
docker run -e 'FLAG=WACon{fake-flag}' -d --rm --name interspace -p 9037:9000 interspace
