#!/usr/bin/env python3

import difflib
import itertools
import random
import os
import re
import signal
import string
import time

def bye(*args):
    print("Bye!")
    exit(1)

signal.signal(signal.SIGALRM, bye)
signal.alarm(5)

STEPS = 10
FLAG = os.environ.get("FLAG", "WACon{fake-flag}")

print("Flag distance calculator:")

for i in range(STEPS):
    candidate = input("> ").strip()
    if candidate == FLAG:
        print("Congratulations!")
        exit(0)
    elif candidate:
        print(1 - difflib.SequenceMatcher(None, candidate, FLAG).ratio())

bye()
