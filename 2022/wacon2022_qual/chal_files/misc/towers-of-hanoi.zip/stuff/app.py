#!/usr/bin/env python3

from collections import OrderedDict

import itertools
import os
import random
import re
import signal
import string
import sys
import time

def bye(*args):
    print("Bye!")
    exit(1)

signal.signal(signal.SIGALRM, bye)
signal.alarm(30)

BANNER = """
████████╗░█████╗░░██╗░░░░░░░██╗███████╗██████╗░░██████╗  ░█████╗░███████╗  ██╗░░██╗░█████╗░███╗░░██╗░█████╗░██╗
╚══██╔══╝██╔══██╗░██║░░██╗░░██║██╔════╝██╔══██╗██╔════╝  ██╔══██╗██╔════╝  ██║░░██║██╔══██╗████╗░██║██╔══██╗██║
░░░██║░░░██║░░██║░╚██╗████╗██╔╝█████╗░░██████╔╝╚█████╗░  ██║░░██║█████╗░░  ███████║███████║██╔██╗██║██║░░██║██║
░░░██║░░░██║░░██║░░████╔═████║░██╔══╝░░██╔══██╗░╚═══██╗  ██║░░██║██╔══╝░░  ██╔══██║██╔══██║██║╚████║██║░░██║██║
░░░██║░░░╚█████╔╝░░╚██╔╝░╚██╔╝░███████╗██║░░██║██████╔╝  ╚█████╔╝██║░░░░░  ██║░░██║██║░░██║██║░╚███║╚█████╔╝██║
░░░╚═╝░░░░╚════╝░░░░╚═╝░░░╚═╝░░╚══════╝╚═╝░░╚═╝╚═════╝░  ░╚════╝░╚═╝░░░░░  ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝░╚════╝░╚═╝
""".rstrip()

FLAG = os.environ.get("FLAG", "WACon{fake-flag}")
LEVELS = ("123,,", "12345,,", "123456789,,".replace(str(random.randint(1, 9)), ""))

print(BANNER)

def shuffle(level, steps):
    towers = OrderedDict()

    i = 0
    for part in level.split(','):
        towers[string.ascii_uppercase[i]] = [_ for _ in part]
        i += 1

    i = 0
    while i < steps:
        move = "".join(random.sample([_ for _ in itertools.permutations("ABC", 2)], 1)[0])
        try:
            towers[move[1]].insert(0, towers[move[0]].pop(0))
        except:
            pass
        else:
            i += 1

    return ','.join("".join(towers[_]) for _ in towers)

def check(level, solution):
    towers = OrderedDict()

    i = 0
    for part in level.split(','):
        towers[string.ascii_uppercase[i]] = [_ for _ in part]
        i += 1

    for i in range(0, len(solution), 2):
        move = solution[i:i+2]
        try:
            towers[move[1]].insert(0, towers[move[0]].pop(0))
        except:
            towers.clear()
            break

    return sum(len(towers[_]) != 0 for _ in towers) == 1 and len(towers[max(towers)]) > 0 and sorted(towers[max(towers)]) == towers[max(towers)]

print("\nWelcome PLAYER! You know the game. Rules are simple:")
print("\n*) 3 levels of difficulty (depending on number of disks)")
print("*) 3 towers (A, B and C)")
print("*) Fill the tower C with all the disks, from top to bottom, from lowest to biggest in diameter")
print("*) If the simplest starting position is represented as '123,,' then the ending position would be represented ',,123'")
print("*) From starting position '123,,' to move the top disk 1 from tower A to tower C, then top disk 2 from tower A to tower B, moves would be represented as 'ACAB'. Ending position would be represented as '3,2,1'")

i = 1
for level in LEVELS:
    level = shuffle(level, random.randint(5, 10))
    print(f"\n# Level {i}: {level}")

    solution = re.sub(r"\s", "", input("> "))

    if len(solution) % 2 == 1 or not check(level, solution):
        bye()

    i += 1

print(f"\nCongratulations! Here is the flag: {FLAG}")
