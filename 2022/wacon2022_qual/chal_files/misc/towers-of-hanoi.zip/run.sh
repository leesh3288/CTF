#/bin/sh

docker kill towers-of-hanoi 2>/dev/null
docker build . -t towers-of-hanoi
docker run -e 'FLAG=WACon{fake-flag}' -d --rm --name towers-of-hanoi -p 9038:9000 towers-of-hanoi
