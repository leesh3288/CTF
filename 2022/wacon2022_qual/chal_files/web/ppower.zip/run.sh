#!/bin/sh
# docker build . -t ppower
docker run -d --rm --name ppower -p 8000:8000 ppower
